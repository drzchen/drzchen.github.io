import java.util.*;
import java.io.*;

public class example 
{
  public final static int bound = 200; 

  public static void main(String[] args)
  {
      int i = 0;
      FileWriter f1 = null;
      FileWriter f2 = null;
      FileWriter f3 = null;
      FileWriter f4 = null;
      FileWriter f5 = null;

      try
      {
        for(; i < bound; i++)
        { 
	f1 = new FileWriter(File.createTempFile("output_1", ".txt"));
	f2 = new FileWriter(File.createTempFile("output_2", ".txt"));
	f3 = new FileWriter(File.createTempFile("output_3", ".txt"));
	f4 = new FileWriter(File.createTempFile("output_4", ".txt"));
	f5 = new FileWriter(File.createTempFile("output_5", ".txt"));

	f1.write("testing\n");
	f2.write("testing\n");
	f3.write("testing\n");
	f4.write("testing\n");
	f5.write("testing\n");

	f1.write("testing\n");
	f2.write("testing\n");
	f4.write("testing\n");
	f5.write("testing\n");

	f1.write("testing\n");
	f3.write("testing\n");
	f5.write("testing\n");

	f1.close();
	f2.close();
	f3.close(); 
        if(i != bound/2) f4.close(); 
        f5.close(); 
        }		
      } 
      catch (Exception e) 
      {
	System.out.println("Catched an exception.");
      } 
  }
}



