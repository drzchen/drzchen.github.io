#include <stdio.h> 
#include <stdlib.h> 

int bound = 200;

int main() 
{
  int i = 0;
  FILE *f1 = NULL;
  FILE *f2 = NULL;
  FILE *f3 = NULL;
  FILE *f4 = NULL;
  FILE *f5 = NULL;

  for(; i < bound; i++)
  { 
    f1 = fopen("output_1.txt","w");
    f2 = fopen("output_2.txt","w");
    f3 = fopen("output_3.txt","w");
    f4 = fopen("output_4.txt","w");
    f5 = fopen("output_5.txt","w");

    fputs("testing\n", f1);
    fputs("testing\n", f2);
    fputs("testing\n", f3);
    fputs("testing\n", f4);
    fputs("testing\n", f5);

    fputs("testing\n", f1);
    fputs("testing\n", f2);
    fputs("testing\n", f4);
    fputs("testing\n", f5);

    fputs("testing\n", f1);
    fputs("testing\n", f3);
    fputs("testing\n", f5);

    fclose(f1);
    fclose(f2);
    fclose(f3); 
    if(i != bound/2) fclose(f4); 
    fclose(f5);
  }
  return 0;
}

