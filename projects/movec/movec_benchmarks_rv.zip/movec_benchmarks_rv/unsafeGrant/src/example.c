#include <stdio.h> 
#include <stdlib.h> 

typedef struct Resource
{
  int id;
} Resource;

typedef struct Task
{
  int id;
} Task;

void grant(Task *t, Resource *r)
{
}

void release(Task *t, Resource *r)
{
}

int bound = 500;

int main() 
{
  int i;
  Task *t1, *t2;
  Resource *r1, *r2;
  for(i = 0; i < bound; i++)
  {
    t1 = (Task *)malloc(sizeof(Task));
    t2 = (Task *)malloc(sizeof(Task));
    r1 = (Resource *)malloc(sizeof(Resource));
    r2 = (Resource *)malloc(sizeof(Resource));
    /*printf("%p %p %p %p\n",t1,t2,r1,r2);*/
    grant(t1,r1);
    grant(t2,r1);
    release(t1,r1);
    release(t2,r2);
  }
  return 0;
}

