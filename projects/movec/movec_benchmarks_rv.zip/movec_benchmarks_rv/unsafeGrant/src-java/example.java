import java.util.*;
import java.io.*;

class Resource 
{
  public int id;
}

class Task 
{
  public int id;

  public void grant(Object r)
  { 
  }

  public void release(Object r)
  { 
  }
}

public class example 
{
  public final static int bound = 500;      

  public static void main(String[] args)
  {
    int i;
    Task t1, t2;
    Resource r1, r2;
    for(i = 0; i < bound; i++)
    {
      t1 = new Task();
      t2 = new Task();
      r1 = new Resource();
      r2 = new Resource();

      t1.grant((Object)r1);
      t2.grant((Object)r1);
      t1.release((Object)r1);
      t2.release((Object)r2);
    }
  }
}



