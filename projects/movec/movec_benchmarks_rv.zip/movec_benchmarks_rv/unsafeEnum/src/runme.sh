#!/bin/sh
./all > output.txt

