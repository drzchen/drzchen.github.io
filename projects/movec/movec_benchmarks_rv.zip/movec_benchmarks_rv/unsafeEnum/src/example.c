#include <stdio.h> 
#include <stdlib.h> 

int bound = 1000;

struct vector { int value; struct vector *next; };
typedef struct vector vector;
struct enumeration { int *start; int count; int *current; };
typedef struct enumeration enumeration;

/*Return a vector containing [1,...,max].*/
vector *vec_init(int max) 
{
  vector *v = NULL, *node;
  int i;

  if(max <= 0) return NULL;

  v = (vector *)malloc(sizeof(vector));
  v->value = max;
  v->next  = NULL;

  for(i = max - 1; i >= 1; i--) 
  {
    node = (vector *)malloc(sizeof(vector));
    node->value = i;
    node->next  = v;
    v = node;
  }
  return v;
}

/*Return the vector after inserting a new value to v.*/
vector *vec_add(vector *v, int value) 
{
  vector *p; 
  if(v == NULL)
  {
    v = (vector *)malloc(sizeof(vector));
    v->value = value;
    v->next  = NULL;
  }
  else
  {  
    p = (vector *)malloc(sizeof(vector));
    p->value = v->value;
    p->next  = v->next;
    v->value = value;
    v->next  = p;
  } 
  return v;
}

/*Return the vector after removing all nodes containing value.*/
vector *vec_remove(vector *v, int value) 
{
  vector *pre = v, *cur = v; 
  while(v && v->value == value) 
  {
    v = v->next;
    free(pre);
    pre = cur = v;
  }
  if(!v) return v; 

  cur = cur->next;
  while(cur) 
  {
    if(cur->value == value) 
    {
      pre->next = cur->next;
      free(cur);
      cur = pre->next;
    }
    else  
    {
      pre = cur;
      cur = cur->next;
    }
  } 
  return v;
}

/*Return a new vector which is a clone of v.*/
vector *vec_clone(vector *v) 
{
  vector *new_vec = NULL, *pre; 
  vector *node;

  if(v == NULL) return NULL;

  new_vec = (vector *)malloc(sizeof(vector));
  new_vec->value = v->value;
  new_vec->next  = NULL;
  pre = new_vec;

  v = v->next;
  while(v != NULL)
  {
    node = (vector *)malloc(sizeof(vector));
    node->value = v->value;
    node->next  = NULL;
    pre->next = node;
    pre = node;

    v = v->next;
  } 
  return new_vec;
}

/*Free a vector.*/
void vec_free(vector **v) 
{
  if((*v)->next)
    vec_free( &((*v)->next) );
  free(*v);
  *v = NULL;
}

/*Return the size of the vector v.*/
int vec_size(vector *v)
{
  int count = 0;
  while(v)
  {
    v = v->next;
    count++;
  }
  return count;
}

/*Create an enumberation from a vector v.*/
enumeration *vec_elements(vector *v) 
{
  int size = vec_size(v);
  int i = 0;

  enumeration *e = (enumeration *)malloc(sizeof(enumeration)); 
  if(size == 0) 
  {
    e->start = NULL;
    e->count = 0;
    e->current = NULL;
    return e;
  }   

  e->start = (int *)malloc(sizeof(int)*size);
  e->count = size;
  e->current = e->start;
  while(v) 
  {
    e->start[i] = v->value; 
    v = v->next; 
  }
  
  return e;
}

void enum_print(enumeration *e) 
{
  int i = 0; 
  printf("\nenum: [");
  for(i = 0; i < e->count; i++)
    printf("%d ",e->start[i]);
  printf("]\n");
}

int enum_hasnext(enumeration *e) 
{
  if(e->start == NULL) 
    return 0;

  if(e->current >= e->start + e->count)
    return 0;
  else
    return 1;
}

int enum_nextElement(enumeration *e) 
{ 
  int error = -1;
  if(e->start == NULL) 
    return error;

  if(e->current >= e->start + e->count)
    return error;
  else
    return *(e->current++); 
}

int test(vector *v, int seqno)
{
  int j = 0;
  enumeration *e = vec_elements(v); 
  
  for(; j < 100; j++)
  {
    if(seqno == bound/2) v = vec_add(v, 0);
    enum_nextElement(e);
  } 
  return 1;
}

int main() 
{
  int i = 0;  
  vector *v = NULL;
  vector *new_vec = NULL;  

  for(i = 0; i < 100; i++)
  {
    v = vec_add(v, i);
  }

  for(i = 0; i < bound; i++)
  {
    new_vec = vec_clone(v);
    test(new_vec, i);
    vec_free(&new_vec);
  }  

  vec_free(&v);
  
  return 0;
}
