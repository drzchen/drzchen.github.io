#!/bin/sh
java example > output.txt

