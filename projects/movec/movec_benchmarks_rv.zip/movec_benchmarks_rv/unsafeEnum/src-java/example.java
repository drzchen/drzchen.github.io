import java.util.*;

public class example 
{
   public static final int bound = 1000;
   
   public static int test(Vector<Integer> v, int seqno)
   {  
     try
     {
       int j = 0;
       Enumeration e = v.elements();

       for(; j < 100; j++)
       {
         if(seqno == bound/2) v.add(0); 
         if(e.hasMoreElements()) e.nextElement();
       } 
     }
     catch(Exception e)
     {
       System.out.println("Catched an exception.");
     } 
     return 1;    
   }

   public static void main(String[] args)
   { 
     int i = 0;
     Vector<Integer> v = new Vector<Integer>();

     for(i = 0; i < 100; i++)
     { 
       v.add(i); 
     }

     for(i = 0; i < bound; i++)
     { 
       Vector<Integer> new_vec = new Vector<Integer>();
       new_vec = (Vector<Integer>)v.clone();
       test(new_vec, i);	 
     }
   }
}

