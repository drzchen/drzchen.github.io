#include <stdio.h> 
#include <stdlib.h> 

int bound = 500;

struct map {int key; int value; struct map *next; };
typedef struct map map;

struct collection { int a; struct collection *next; };
typedef struct collection collection;

struct iterator { struct collection *last; struct collection *current; };
typedef struct iterator iterator;

/*Return the size of the map m.*/
int map_size(map *m)
{
  int count = 0;
  while(m)
  {
    m = m->next;
    count++;
  }
  return count;
}

/*Create an collection of keys from a map m.*/
collection *map_keySet(map *m)
{ 
  collection *c = NULL, *node;

  while(m) 
  {
    if(c == NULL)
    {
      c = (collection *)malloc(sizeof(collection));
      c->a = m->key;
      c->next = NULL;
    }
    else
    {
      node = (collection *)malloc(sizeof(collection));
      node->a = m->key;
      node->next = NULL;
      c->next = node; 
    }
    m = m->next;
  }
  return c;
} 

/*Create an collection of values from a map m.*/
collection *map_values(map *m)
{
  collection *c = NULL, *node;

  while(m) 
  {
    if(c == NULL)
    {
      c = (collection *)malloc(sizeof(collection));
      c->a = m->value;
      c->next = NULL;
    }
    else
    {
      node = (collection *)malloc(sizeof(collection));
      node->a = m->value;
      node->next = NULL;
      c->next = node; 
    }
    m = m->next;
  }
  return c;
} 

/*Return the map after inserting a new key and a new value to m.*/
map *map_put(map *m, int key, int value)
{
  if(m == NULL)
  {
    m = (map *)malloc(sizeof(map));
    m->key = key;
    m->value = value;
    m->next = NULL;    
    return m; 
  } 

  while(m->next) 
  {
    m = m->next;
  } 
  m->next = (map *)malloc(sizeof(map));
  m->next->key = key;
  m->next->value = value;
  m->next->next = NULL;
  return m;
}

/*Return a new map which is a clone of m.*/
map *map_putAll(map *m) 
{
  map *new_m = NULL, *pre; 
  map *node;

  if(m == NULL) return NULL;

  new_m = (map *)malloc(sizeof(map));
  new_m->key = m->key;
  new_m->value = m->value;
  new_m->next  = NULL;
  pre = new_m;

  m = m->next;
  while(m != NULL)
  {
    node = (map *)malloc(sizeof(map));
    node->key = m->key;
    node->value = m->value;
    node->next  = NULL;
    pre->next = node;
    pre = node;

    m = m->next;
  } 
  return new_m;
}

/*Free a map.*/
void map_free(map **m) 
{
  if((*m)->next)
    map_free( &((*m)->next) );
  free(*m);
  *m = NULL;
}

/*Return the size of the collection c.*/
int collection_size(collection *c)
{
  int count = 0;
  while(c)
  {
    c = c->next;
    count++;
  }
  return count;
}

void collection_free(collection *c)
{
  collection *pre;
  while(c)
  {
    pre = c;
    c = c->next;
    free(pre);
  }
}

/*Create an iterator from a collection c.*/
iterator *collection_iterator(collection *c) 
{  
  iterator *i = (iterator *)malloc(sizeof(iterator)); 
  i->current = c;
  while(c && c->next) 
  {
    c = c->next;    
  }
  i->last = c;
  return i;
}

int iterator_next(iterator *i) 
{
  int ret;
  if(i->current == NULL)
    return -1; 
  ret = i->current->a;
  if(i->current == i->last) i->current = NULL;
  else i->current = i->current->next;
  return ret;
}

void test1(map *m, int seqno)
{
  collection *c1 = map_keySet(m);
  iterator *i1 = collection_iterator(c1); 
  m = map_put(m, 3, 4);
  if(seqno == bound/2) iterator_next(i1); 
}

void test2(map *m, int seqno)
{
  collection *c2 = map_values(m);
  iterator *i2 = collection_iterator(c2); 
  m = map_put(m, 5, 6);
  if(seqno == bound/2) iterator_next(i2);
}

int main() 
{
  int i = 0;
  map *m = NULL; 
  map *m1 = NULL; 
  m = map_put(m, 0, 5); 
  m = map_put(m, 1, 10); 
  m1 = map_putAll(m);

  for(; i < bound; i++)
  {      
    m = map_putAll(m1);
    test1(m, i);
    m = map_putAll(m1);
    test2(m, i); 
  }
  return 0;
}

