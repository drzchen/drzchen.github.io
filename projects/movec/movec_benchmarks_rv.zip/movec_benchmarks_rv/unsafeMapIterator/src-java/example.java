import java.util.*;

 public class example 
 {
   public final static int bound = 500;

   public static int test1(Map<Integer,Integer> m, int seqno)
   {  
     try
     {
       Set<Integer> c1 = m.keySet(); //get key set
       Iterator i1 = c1.iterator();
       m.put(3, 4);
       if(seqno == bound/2) i1.next();
     }
     catch(Exception e)
     {
       System.out.println("Catched an exception1.");
     } 
     return 1;    
   }

   public static int test2(Map<Integer,Integer> m, int seqno)
   {
     try
     {
       Collection<Integer> c2 = m.values(); //get value collection
       Iterator i2 = c2.iterator();
       m.put(5, 6);
       if(seqno == bound/2) i2.next();  
     }
     catch(Exception e)
     {
       System.out.println("Catched an exception2.");
     } 
     return 1;  
   }

   public static void main(String[] args)
   {    
      int i = 0;
      Map<Integer,Integer> m  = new HashMap<Integer,Integer>();
      Map<Integer,Integer> m1 = new HashMap<Integer,Integer>();
      m.put(0, 5);
      m.put(1, 10);
      m1.putAll(m);
        
      for(; i < bound; i++)
      {   
        m.putAll(m1);
        test1(m, i);
        m.putAll(m1);
        test2(m, i);       
      } 
   }
 }

